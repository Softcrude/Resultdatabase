<?php
$link = mysqli_connect('localhost', 'root', '','anglicancollege');
//3]r9yp14[4?(
if (!$link) {
    die('Not connected : ' . mysql_error());
}

// make eldi the current db
$db_selected = mysqli_select_db($link,'anglicancollege');
if (!$db_selected) {
    die ('Can\'t use global shipping : ' . mysqli_error($link));
}

?>